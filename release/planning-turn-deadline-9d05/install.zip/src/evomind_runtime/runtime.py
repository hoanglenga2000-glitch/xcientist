from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .model_router import ModelRouter
from .models import ApprovalRequest, PermissionLevel, Session, SessionStatus, ToolCall, ToolResult, new_id, utc_now
from .policy import PolicyEngine, argument_fingerprint
from .store import RuntimeStore
from .tools import ToolContext, ToolRegistry, build_default_registry
from .assistant_runs import AssistantRunService
from .super_agent_runtime import SuperAgentMode, SuperAgentRuntime
from .tenant_access import register_scoped_session, scoped_session_metadata
from .execution_progress import ExecutionHeartbeat, ProgressStore, safe_text

logger = logging.getLogger(__name__)


def _message_max_output_tokens(session: dict[str, Any], client: Any) -> int:
    """Bound ordinary Flash replies without changing calibration allowances.

    A confirmed per-Run request amendment still takes precedence in the
    governed transport. This does not change the pinned model contract.
    """
    if {"official_calibration", "siim_calibration"} & set(session.get("metadata") or {}):
        return 8192
    # Hotfix D9: raise the ordinary Flash output budget. A long planning turn for a
    # large-data training objective still hit model_output_truncated at 16384 tokens
    # (the calibration path already uses 32768, so the provider supports it).
    return 32768 if getattr(client, "model", "") == "deepseek-flash" else 4096



def _history_has_tool_activity(messages: list[dict[str, Any]]) -> bool:
    """True when any earlier turn of this run already carried a tool call or result."""
    for item in messages:
        content = item.get("content") if isinstance(item, dict) else None
        if isinstance(content, list) and any(isinstance(block, dict) and block.get("type") in {"tool_use", "tool_result"} for block in content):
            return True
    return False


def _training_completion_text(store: Any, session_id: str) -> str:
    """Plain-Chinese result of the last successful managed training in this run, or '' (used when the model answers empty)."""
    try:
        calls = store.list_tool_calls(session_id, limit=500)
    except Exception:  # noqa: BLE001
        return ""
    for call in reversed(calls):
        result = call.get("result") if isinstance(call.get("result"), dict) else {}
        content = result.get("content") if isinstance(result.get("content"), dict) else {}
        evidence = content.get("managed_training") if isinstance(content.get("managed_training"), dict) else None
        if call.get("tool_name") != "managed_tensor_train" or not result.get("ok") or not evidence:
            continue
        metrics = evidence.get("metrics") if isinstance(evidence.get("metrics"), dict) else {}
        def number(key: str) -> str:
            value = metrics.get(key)
            return f"{float(value):.4f}" if isinstance(value, (int, float)) and not isinstance(value, bool) else ""
        if evidence.get("task") == "classification":
            parts = [f"{label} {number(key)}" for key, label in (("accuracy", "准确率"), ("macro_f1", "Macro-F1"), ("roc_auc", "ROC-AUC")) if number(key)]
        else:
            parts = [f"{label} {number(key)}" for key, label in (("rmse", "RMSE"), ("mae", "MAE"), ("r2", "R²")) if number(key)]
        holdout = metrics.get("holdout_rows")
        scope = f"（在 {holdout} 行留出数据上评估）" if isinstance(holdout, int) else ""
        headline = "，".join(parts)
        return ("训练完成。" + (f"评估结果{scope}：{headline}。" if headline else "")
                + "模型权重、预测结果、训练日志和评估指标都已保存在这个任务的文件里，可以直接下载。")
    return ""


class AgentRuntime:
    def __init__(
        self, workspace_root: str | Path, runtime_root: str | Path | None = None, registry: ToolRegistry | None = None
    ) -> None:
        self.workspace_root = Path(workspace_root).resolve()
        self.runtime_root = Path(runtime_root or self.workspace_root / "workspace" / "runtime").resolve()
        self.runtime_root.mkdir(parents=True, exist_ok=True)
        self.artifact_root = self.runtime_root / "artifacts"
        self.store = RuntimeStore(self.runtime_root / "runtime.sqlite3")
        self.progress = ProgressStore(self.runtime_root / "runtime.sqlite3")
        self.super_agent = SuperAgentRuntime(
            workspace_root=self.workspace_root,
            runtime_root=self.runtime_root,
            tenant_id=os.getenv("EVOMIND_TENANT_ID", "local"),
            project_id=os.getenv("EVOMIND_PROJECT_ID", self.workspace_root.name or "default"),
        )
        self.registry = registry or build_default_registry()
        self.super_agent.ingest_runtime_tools(self.registry.specs())
        self.policy = PolicyEngine()
        self.router = ModelRouter()
        # ThreadingHTTPServer can deliver duplicate retries concurrently.  Keep
        # the idempotency lookup and the initial durable state transition
        # atomic so only one request is allowed to execute a side effect.
        self._invoke_lock = threading.RLock()
        self.assistant = AssistantRunService(self)
        from .report_jobs import ReportJobs
        self.reports = ReportJobs(self)
        self._close_lock = threading.RLock()
        self._closed = False

    def close(self, timeout: float = 2.0) -> bool:
        if self._closed:
            return True
        if not self.assistant.shutdown(timeout):
            return False
        if not self.reports.shutdown(timeout):
            return False
        with self._close_lock:
            if not self._closed:
                self.super_agent.close()
                self.store.close()
                self._closed = True
        return True

    def create_session(
        self,
        *,
        objective: str = "",
        title: str = "",
        permission_level: str = PermissionLevel.WORKSPACE_WRITE.value,
        workspace_root: str | None = None,
        parent_session_id: str = "",
        session_id: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        PermissionLevel(permission_level)
        metadata = scoped_session_metadata(metadata)
        from .aibuild_engine import use_aibuild
        session_metadata = dict(metadata or {})
        if use_aibuild(objective, session_metadata, self.runtime_root):
            session_metadata["research_orchestrator"] = "aibuildai2"
            from .training_control import load_policy
            control = load_policy(self.runtime_root)
            if control is not None:
                session_metadata["training_control_policy_sha256"] = control["policy_sha256"]
        session = Session(
            session_id or new_id("session"),
            str(Path(workspace_root or self.workspace_root).resolve()),
            permission_level,
            title=title or objective[:80],
            objective=objective,
            parent_session_id=parent_session_id,
            metadata=session_metadata,
        )
        created = self.store.create_session(session).to_dict()
        register_scoped_session(self.runtime_root, created["id"])
        session_tenant_id, session_project_id = self.super_agent.session_identity(created.get("metadata"))
        directory_id = self.super_agent.ensure_session_workspace(
            session_id=created["id"],
            workspace_root=created["workspace_root"],
            tenant_id=session_tenant_id,
            project_id=session_project_id,
        )
        next_metadata = dict(created.get("metadata") or {})
        next_metadata["super_agent_directory_ids"] = [directory_id]
        return self.store.update_session(created["id"], metadata_json=next_metadata)

    def get_session(self, session_id: str) -> dict[str, Any]:
        session = self.store.get_session(session_id)
        if not session:
            raise KeyError(session_id)
        metadata = dict(session.get("metadata") or {})
        session_tenant_id, session_project_id = self.super_agent.session_identity(metadata)
        directory_id = self.super_agent.ensure_session_workspace(
            session_id=session["id"],
            workspace_root=session["workspace_root"],
            tenant_id=session_tenant_id,
            project_id=session_project_id,
        )
        if metadata.get("super_agent_directory_ids") != [directory_id]:
            metadata["super_agent_directory_ids"] = [directory_id]
            session = self.store.update_session(session["id"], metadata_json=metadata)
        return session

    def list_sessions(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.store.list_sessions(limit)

    def ensure_fixed_goal(
        self,
        *,
        run_id: str,
        spec: dict[str, Any],
        board: dict[str, Any],
        status: str = "blocked",
    ) -> dict[str, Any]:
        """Bind the fixed G21 Goal to an existing Run without creating a Run."""

        from .competition_goal import FIXED_RUN_ID, sha256_json
        from .goal_board import GoalRecordError, ensure_fixed_goal

        if run_id != FIXED_RUN_ID:
            raise GoalRecordError("goal run must be the fixed G21 Run")
        session = self.store.get_session(run_id)
        if session is None:
            raise KeyError(run_id)
        expected_metadata = {
            "goal_id": "goal_g21_five_competition",
            "goal_key": "g21_five_competition",
            "goal_spec_sha256": sha256_json(spec),
            "goal_board_sha256": sha256_json(board),
        }
        metadata = dict(session.get("metadata") or {})
        for key, value in expected_metadata.items():
            existing_value = metadata.get(key)
            if existing_value not in (None, value):
                raise GoalRecordError(f"existing session metadata conflicts with {key}")

        result = ensure_fixed_goal(
            self.store,
            run_id=run_id,
            spec=spec,
            board=board,
            status=status,
        )
        record = result["record"]
        return result

    def get_goal(self, run_id: str, goal_key: str = "") -> dict[str, Any] | None:
        return self.store.get_goal_for_run(run_id, goal_key or "g21_five_competition")

    def update_fixed_goal(self, *, goal_id: str, board: dict[str, Any], status: str | None = None) -> dict[str, Any]:
        """Update the fixed Goal board through its validated, evented path."""

        from .competition_goal import FIXED_GOAL_ID, sha256_json
        from .goal_board import GoalRecordError, update_fixed_goal_board

        if goal_id != FIXED_GOAL_ID:
            raise GoalRecordError("goal identity is not the fixed G21 goal")
        current = self.store.get_goal_record(goal_id)
        if current is None:
            raise KeyError(goal_id)
        session = self.store.get_session(str(current["run_id"]))
        if session is None:
            raise KeyError(str(current["run_id"]))
        metadata = dict(session.get("metadata") or {})
        for key, expected in (("goal_id", goal_id), ("goal_key", current["goal_key"])):
            if metadata.get(key) not in (None, expected):
                raise GoalRecordError(f"existing session metadata conflicts with {key}")
        if metadata.get("goal_board_sha256") not in (None, current["board_sha256"]):
            raise GoalRecordError("existing session metadata conflicts with goal_board_sha256")
        return update_fixed_goal_board(
            self.store,
            goal_id=goal_id,
            board=board,
            status=status,
            session_metadata={
                "goal_id": goal_id,
                "goal_key": current["goal_key"],
                "goal_spec_sha256": current["spec_sha256"],
                "goal_board_sha256": sha256_json(board),
                "goal_human_baseline_sha256": str(
                    board.get("human_baseline_evidence_sha256")
                    or current.get("human_baseline_sha256")
                    or ""
                ),
            },
        )

    def migrate_fixed_goal_policy(
        self,
        *,
        goal_id: str,
        run_id: str,
        expected_spec_sha256: str,
        new_spec: dict[str, Any],
        policy_evidence: dict[str, Any],
        migration_id: str,
    ) -> dict[str, Any]:
        """Migrate only the fixed Goal policy through the atomic store path."""

        from .competition_goal import FIXED_GOAL_ID, FIXED_RUN_ID
        from .goal_board import GoalRecordError

        if goal_id != FIXED_GOAL_ID or run_id != FIXED_RUN_ID:
            raise GoalRecordError("goal policy migration identity mismatch")
        current = self.store.get_goal_record(goal_id)
        if current is None:
            raise KeyError(goal_id)
        if current.get("run_id") != run_id:
            raise GoalRecordError("goal policy migration cross-run binding rejected")
        record, migrated = self.store.migrate_goal_policy(
            goal_id,
            run_id=run_id,
            expected_spec_sha256=expected_spec_sha256,
            new_spec=new_spec,
            policy_evidence=policy_evidence,
            migration_id=migration_id,
        )
        return {"record": record, "migrated": migrated}

    def tools(self) -> list[dict[str, Any]]:
        return [spec.to_dict() for spec in self.registry.specs()]

    def _training_plan_scope(self, session: dict[str, Any], arguments: dict[str, Any]) -> dict[str, Any]:
        """Display-only training plan for the consent card; absent when it cannot be computed."""
        try:
            from . import gpu_vram, training_plan
            from .personal_tool_boundary import session_tenant
            try:
                budget = int(gpu_vram.load(self.runtime_root).ceiling_mb(session_tenant(session)))
            except Exception:  # noqa: BLE001 - same fallback as the trainer (4 GiB)
                budget = None
            plan = training_plan.build(session["workspace_root"], arguments, vram_budget_mb=budget)
        except Exception:  # noqa: BLE001
            plan = None
        return {"training_plan": plan} if plan else {}

    def invoke_tool(
        self,
        session_id: str,
        tool_name: str,
        arguments: dict[str, Any],
        *,
        tool_call_id: str = "",
        approved_fingerprint: str = "",
        idempotency_key: str = "",
    ) -> dict[str, Any]:
        session = self.get_session(session_id)
        pre_decision = self.policy.evaluate(
            tool_name=tool_name,
            arguments=arguments,
            permission_level=session["permission_level"],
            workspace_root=session["workspace_root"],
            approved_fingerprint="",
        )
        if tool_call_id:
            call_id = tool_call_id
        elif idempotency_key:
            stable_key = argument_fingerprint("idempotency", {"session_id": session_id, "key": idempotency_key})
            call_id = f"call_{stable_key[:32]}"
        else:
            call_id = new_id("call")

        if idempotency_key:
            try:
                with self._invoke_lock:
                    prior = self.store.get_idempotent_tool_call(session_id, idempotency_key)
                if prior:
                    call_id = str(prior["id"])
            except ValueError:
                result = ToolResult(call_id, False, {}, "Idempotency history requires reconciliation; no action was started", error="idempotency_conflict")
                return {"status": "failed", "result": result.to_dict(), "replayed": True}

        approval_verified = False
        approval_id = ""
        verified_fingerprint = ""
        if approved_fingerprint:
            candidate_call = self.store.get_tool_call(call_id)
            candidate_approval = (
                self.store.get_approval(str(candidate_call.get("approval_id") or ""))
                if candidate_call and candidate_call.get("approval_id")
                else None
            )
            expires_at = datetime.min.replace(tzinfo=timezone.utc)
            if candidate_approval:
                try:
                    expires_at = datetime.fromisoformat(
                        str(candidate_approval.get("expires_at") or "").replace("Z", "+00:00")
                    )
                    if expires_at.tzinfo is None:
                        expires_at = expires_at.replace(tzinfo=timezone.utc)
                except ValueError:
                    pass
            approval_verified = bool(
                candidate_call
                and candidate_approval
                and candidate_call.get("session_id") == session_id
                and candidate_call.get("tool_name") == tool_name
                and candidate_call.get("arguments") == pre_decision.normalized_arguments
                and candidate_approval.get("session_id") == session_id
                and candidate_approval.get("tool_call_id") == call_id
                and candidate_approval.get("tool_name") == tool_name
                and candidate_approval.get("normalized_arguments") == pre_decision.normalized_arguments
                and candidate_approval.get("status") == "approved"
                and candidate_approval.get("argument_fingerprint") == approved_fingerprint
                and expires_at > datetime.now(timezone.utc)
            )
            if approval_verified:
                approval_id = str(candidate_approval["id"])
                verified_fingerprint = approved_fingerprint

        decision = self.policy.evaluate(
            tool_name=tool_name,
            arguments=arguments,
            permission_level=session["permission_level"],
            workspace_root=session["workspace_root"],
            approved_fingerprint=verified_fingerprint,
        )
        from .personal_tool_boundary import constrain
        pre_decision = constrain(session, tool_name, pre_decision)
        decision = constrain(session, tool_name, decision)

        def admit(call, result=None, approval=None):
            spec = self.registry.get(tool_name)
            try:
                claimed, saved = self.store.admit_tool_call(
                    call, result, approval=approval, approved_fingerprint=verified_fingerprint,
                    allow_paused=bool(spec and spec.read_only),
                )
            except ValueError:
                failure = ToolResult(call.id, False, {}, "Tool admission requires reconciliation; no action was started",
                                     error="idempotency_conflict")
                return {"status": "failed", "result": failure.to_dict(), "replayed": True, "dispatched": False}
            if claimed:
                return None
            if "id" not in saved:
                return saved
            replay = {"status": saved["status"], "tool_call": saved, "replayed": True}
            if saved["status"] in {"completed", "failed"}:
                replay["result"] = saved["result"]
            elif saved["status"] == "waiting_approval":
                replay["approval"] = self.store.get_approval(saved["approval_id"])
            return replay

        with self._invoke_lock:
            if idempotency_key:
                try:
                    latest = self.store.get_idempotent_tool_call(session_id, idempotency_key)
                except ValueError:
                    result = ToolResult(call_id, False, {}, "Idempotency history requires reconciliation; no action was started", error="idempotency_conflict")
                    return {"status": "failed", "result": result.to_dict(), "replayed": True}
                if latest and latest["id"] != call_id:
                    call_id = str(latest["id"])
                    approval_verified, approval_id, verified_fingerprint = False, "", ""
                    decision = pre_decision
            existing = self.store.get_tool_call(call_id)
            if existing:
                same_request = (
                    existing["session_id"] == session_id
                    and existing["tool_name"] == tool_name
                    and existing["arguments"] == decision.normalized_arguments
                    and (not idempotency_key or existing.get("idempotency_key") == idempotency_key)
                )
                if not same_request:
                    conflict = ToolResult(
                        call_id,
                        False,
                        {"existing_tool_name": existing["tool_name"], "existing_arguments": existing["arguments"]},
                        "idempotency key is already bound to a different tool request",
                        error="idempotency_conflict",
                    )
                    return {"status": "failed", "result": conflict.to_dict(), "replayed": True}
                if existing["status"] in {"completed", "failed"}:
                    return {
                        "status": existing["status"],
                        "tool_call": existing,
                        "result": existing["result"],
                        "replayed": True,
                    }
                if existing["status"] == "waiting_approval" and not approval_verified:
                    approval = self.store.get_approval(existing["approval_id"])
                    approval_status = str((approval or {}).get("status") or "")
                    try:
                        deadline = datetime.fromisoformat(str((approval or {}).get("expires_at") or "").replace("Z", "+00:00"))
                        if deadline.tzinfo is None:
                            deadline = deadline.replace(tzinfo=timezone.utc)
                    except ValueError:
                        deadline = datetime.min.replace(tzinfo=timezone.utc)
                    if approval_status in {"pending", "approved"} and deadline > datetime.now(timezone.utc):
                        return {"status": "waiting_approval", "tool_call": existing, "approval": approval, "replayed": True}
                    if approval_status == "pending":
                        self.store.decide_approval(existing["approval_id"], False, "expired before replay")
                    # Expired/rejected gates are immutable evidence. A
                    # same-request retry must get a fresh call/approval.
                    call_id = new_id("call")
                    existing = None
                if existing and existing["status"] == "running":
                    return {"status": "running", "tool_call": existing, "replayed": True}

            if self.get_session(session_id)["status"] == "cancelled":
                return {"status": "cancelled", "error": "user_cancel_requested", "dispatched": False}
            if self.user_pause_requested(session_id):
                spec = self.registry.get(tool_name)
                if spec is None or not spec.read_only:
                    return {"status": "paused", "error": "user_pause_requested", "dispatched": False}

            breaker = None if approval_verified else self._tool_breaker(session, session_id, tool_name,
                                                                        decision.normalized_arguments, call_id)
            if breaker is not None:
                refused = ToolCall(call_id, session_id, tool_name, decision.normalized_arguments, idempotency_key=idempotency_key)
                refused.status, refused.completed_at = "failed", utc_now()
                replay = admit(refused, breaker)
                if replay is not None:
                    return replay
                self.store.append_event(session_id, "tool.failed", breaker.to_dict())
                return {"status": "failed", "result": breaker.to_dict(), "decision": decision.to_dict()}

            call = ToolCall(
                call_id, session_id, tool_name, decision.normalized_arguments, idempotency_key=idempotency_key
            )
            if approval_verified:
                call.approval_id = approval_id
            if decision.requires_approval:
                call.status = "waiting_approval"
                impact_scope = dict(decision.scope)
                if tool_name == "managed_tensor_train":
                    # 2026-11-03: the consent card shows the plan (task, network, epochs, estimated on-card time) before the GPU.
                    impact_scope.update(self._training_plan_scope(session, decision.normalized_arguments))
                approval = ApprovalRequest(
                    new_id("approval"),
                    session_id,
                    call.id,
                    tool_name,
                    argument_fingerprint(tool_name, decision.normalized_arguments),
                    decision.normalized_arguments,
                    impact_scope,
                    decision.risk_level,
                    decision.reversible,
                    expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
                )
                call.approval_id = approval.id
                replay = admit(call, approval=approval)
                if replay is not None:
                    return replay
                self.store.update_session(session_id, status=SessionStatus.WAITING_APPROVAL.value)
                self.store.append_event(session_id, "approval.requested", approval.to_dict())
                self.store.checkpoint(
                    session_id, {"phase": "waiting_approval", "tool_call_id": call.id, "approval_id": approval.id}
                )
                return {"status": "waiting_approval", "tool_call": call.to_dict(), "approval": approval.to_dict()}
            if not decision.allowed:
                error_code = "personal_tool_boundary" if decision.scope.get("personal_tool_boundary") else "cross_run_path" if decision.scope.get("cross_run_workspace") else "permission_denied"
                result = ToolResult(call.id, False, {}, decision.reason, error=error_code)
                call.status, call.completed_at = "failed", utc_now()
                replay = admit(call, result)
                if replay is not None:
                    return replay
                self.store.append_event(session_id, "tool.failed", result.to_dict())
                return {"status": "failed", "result": result.to_dict(), "decision": decision.to_dict()}
            call.status, call.started_at = "running", utc_now()
            replay = admit(call)
            if replay is not None:
                return replay
            self.store.update_session(session_id, status=SessionStatus.RUNNING.value)
            self.store.append_event(session_id, "tool.started", call.to_dict())
        context = ToolContext(
            session_id,
            Path(session["workspace_root"]),
            self.workspace_root,
            self.runtime_root,
            self.artifact_root,
            self.store,
            dict(session.get("metadata") or {}),
            self.super_agent,
            approval_verified,
            approval_id,
            verified_fingerprint,
        )
        context.reports = self.reports
        with ExecutionHeartbeat(
            self.progress, session_id, call.id,
            lambda payload: self.store.append_event(session_id, "run_progress", payload),
        ) as heartbeat:
            context.progress = heartbeat.report
            result = self._invoke_with_slot_policy(session_id, tool_name, decision.normalized_arguments, context)
            heartbeat.report(phase="tool_completed" if result.ok else "tool_failed", worker_state="unverified", failure_class=safe_text(result.error))
        result.tool_call_id = call.id
        call.status, call.completed_at = ("completed" if result.ok else "failed"), utc_now()
        self.store.put_tool_call(call, result)
        self.store.append_event(session_id, f"tool.{call.status}", result.to_dict())
        self.store.checkpoint(session_id, {"phase": "observation_confirmed", "tool_call_id": call.id, "ok": result.ok})
        self.settle_user_pause(session_id)
        return {"status": call.status, "result": result.to_dict(), "decision": decision.to_dict()}

    def _invoke_with_slot_policy(self, session_id: str, tool_name: str, arguments: dict[str, Any], context: Any) -> ToolResult:
        """Run supervision v1: a GPU tool gives its run's model slot back while the GPU scheduler owns the work."""
        from .run_supervision import GPU_SLOT_RELEASE_TOOLS

        assistant = getattr(self, "assistant", None)
        slots = getattr(assistant, "slots", None)
        if slots is None or tool_name not in GPU_SLOT_RELEASE_TOOLS:
            return self.registry.invoke(tool_name, arguments, context)
        with slots.released_for_gpu(session_id):
            return self.registry.invoke(tool_name, arguments, context)

    def _tool_breaker(self, session: dict[str, Any], session_id: str, tool_name: str, arguments: dict[str, Any],
                      call_id: str) -> ToolResult | None:
        """Run supervision v1: refuse a call that can only fail again (identical x3, or the tool x10 same error)."""
        from .run_supervision import tool_breaker_verdict

        metadata = dict(session.get("metadata") or {})
        circuit = dict(metadata.get("tool_circuit") or {}) if isinstance(metadata.get("tool_circuit"), dict) else {}
        try:
            failed = self.store.list_failed_tool_calls(session_id, tool_name, since=str(metadata.get("breaker_reset_at") or ""))
        except Exception:  # noqa: BLE001 - the breaker never blocks a call it cannot judge
            return None
        verdict = tool_breaker_verdict(failed, tool_name, arguments, open_tools=circuit.keys())
        if not verdict.refuse:
            return None
        if verdict.reason == "identical_call":
            message = (f"This exact {tool_name} call already failed {verdict.count} times with the same arguments; it was not run again. "
                       "Change the arguments or take another approach instead of repeating it.")
            return ToolResult(call_id, False, {"count": verdict.count, "remote_dispatched": False}, message,
                              error="repeated_identical_failure")
        if tool_name not in circuit:
            circuit[tool_name] = {"code": verdict.code, "count": verdict.count, "opened_at": utc_now()}
            metadata["tool_circuit"] = circuit
            self.store.update_session(session_id, metadata_json=metadata)
            self.store.append_event(session_id, "tool_circuit_opened", {"tool": tool_name, "code": verdict.code, "count": verdict.count})
            ledger = getattr(getattr(self, "assistant", None), "ledger", None)
            if ledger is not None:
                try:
                    ledger.failure(session_id, signature=f"tool:{tool_name}:{verdict.code}", category="tool_circuit_open",
                                   node_id=tool_name, count=verdict.count)
                except Exception:  # noqa: BLE001
                    pass
        info = circuit.get(tool_name) or {}
        message = (f"{tool_name} failed {info.get('count') or verdict.count} times with the same error in this run and is paused until "
                   "the user resumes the run. Do not call it again; finish with what is verified and tell the user which step needs their help.")
        return ToolResult(call_id, False, {"remote_dispatched": False}, message, error="tool_circuit_open")

    def decide_approval(self, approval_id: str, approved: bool, note: str = "", *, execute: bool = True) -> dict[str, Any]:
        with self._invoke_lock:
            approval = self.store.decide_approval(approval_id, approved, note)
            call = self.store.get_tool_call(approval["tool_call_id"])
            if not call:
                raise KeyError(approval["tool_call_id"])
            if not approved or approval["status"] != "approved":
                self.store.update_session(approval["session_id"], status=SessionStatus.PAUSED.value)
                return {"status": approval["status"], "approval": approval}
            if not execute:
                return {"status": "approved", "approval": approval, "tool_call": call}
        # Never hold the global admission lock during a long external action.
        return self.invoke_tool(
            approval["session_id"], call["tool_name"], call["arguments"],
            tool_call_id=call["id"], approved_fingerprint=approval["argument_fingerprint"],
            idempotency_key=call["idempotency_key"],
        )

    def user_pause_requested(self, session_id: str) -> bool:
        session = self.get_session(session_id)
        return bool((session.get("metadata") or {}).get("user_pause_requested"))

    def pause(self, session_id: str) -> dict[str, Any]:
        with self._invoke_lock:
            session = self.get_session(session_id)
            if session["status"] in {"completed", "cancelled"}:
                return session
            if self.store.set_user_pause_requested(session_id, True):
                self.store.append_event(session_id, "session.pause_requested", {"signals_sent": 0, "new_work_blocked": True})
        self.settle_user_pause(session_id)
        return self.get_session(session_id)

    def settle_user_pause(self, session_id: str) -> None:
        with self._invoke_lock:
            if not self.user_pause_requested(session_id):
                return
            run = self.store.get_assistant_run(session_id)
            if run and str(run.get("error_class") or "") in {
                "execution_reconciliation_required", "approval_execution_unconfirmed",
            }:
                return
            pending = any(call["status"] == "running" for call in self.store.list_tool_calls(session_id, limit=2000))
            worker = self.assistant._threads.get(session_id)
            # Inspect handles without acquiring the assistant lock (lock order).
            control_alive = bool(worker and worker.is_alive())
            state = "pausing" if pending or control_alive else "paused"
            previous_state = self.get_session(session_id)["status"]
            self.store.update_session(session_id, status=state)
            if self.store.get_assistant_run(session_id):
                self.store.update_assistant_run(session_id, status=state, completed_at="")
            if state == "paused" and previous_state != "paused":
                self.store.append_event(session_id, "run_paused", {"status": "paused", "signals_sent": 0, "budget_reset": False})

    def clear_user_pause(self, session_id: str) -> None:
        with self._invoke_lock:
            if any(call["status"] == "running" for call in self.store.list_tool_calls(session_id, limit=2000)):
                raise ValueError("pause_resume_requires_tool_settlement")
            if self.store.set_user_pause_requested(session_id, False):
                self.store.update_session(session_id, status="recovering")
                self.store.append_event(session_id, "session.pause_released", {"budget_reset": False, "tools_replayed": False})

    def resume(self, session_id: str) -> dict[str, Any]:
        if self.user_pause_requested(session_id):
            self.clear_user_pause(session_id)
        pending = self.store.pending_tool_call(session_id)
        if pending:
            approval = self.store.get_approval(pending["approval_id"])
            if approval and approval["status"] == "approved":
                return self.invoke_tool(
                    session_id,
                    pending["tool_name"],
                    pending["arguments"],
                    tool_call_id=pending["id"],
                    approved_fingerprint=approval["argument_fingerprint"],
                    idempotency_key=pending.get("idempotency_key", ""),
                )
            return {"status": "waiting_approval", "tool_call": pending, "approval": approval}
        checkpoint = self.store.latest_checkpoint(session_id)
        self.store.update_session(session_id, status=SessionStatus.RUNNING.value)
        self.store.append_event(session_id, "session.resumed", {"checkpoint": checkpoint})
        return {"status": "resumed", "checkpoint": checkpoint}

    def cancel(self, session_id: str) -> dict[str, Any]:
        with self._invoke_lock:
            self.store.set_user_pause_requested(session_id, False)
            session = self.store.update_session(session_id, status=SessionStatus.CANCELLED.value)
        self.store.append_event(session_id, "session.cancelled", {})
        self._cancel_gpu_job(session_id)
        return session

    def _cancel_gpu_job(self, session_id: str) -> None:
        """t238 C7c: the gate's waiter and the lease supervisor see this; the session state alone reaches neither."""
        from . import gpu_admission

        try:
            gpu_admission.cancel_run(self.runtime_root, session_id)
        except Exception as error:  # noqa: BLE001 - the Run is cancelled either way; the lease deadline still bounds the job
            self.store.append_event(session_id, "gpu.cancel_failed", {"error": type(error).__name__})

    # Statuses that claim work is in flight.  A session may only rest in one of
    # them while some piece of live evidence supports it (an active tool call, a
    # fresh approval gate, or an assistant Run that still owns the lifecycle).
    ACTIVE_SESSION_STATUSES = (
        SessionStatus.QUEUED.value,
        SessionStatus.PLANNING.value,
        SessionStatus.RUNNING.value,
        SessionStatus.VERIFYING.value,
        SessionStatus.WAITING_APPROVAL.value,
        SessionStatus.RECOVERING.value,
    )
    ACTIVE_RUN_STATUSES = (
        SessionStatus.CREATED.value,
        SessionStatus.QUEUED.value,
        SessionStatus.PLANNING.value,
        SessionStatus.RUNNING.value,
        SessionStatus.VERIFYING.value,
        SessionStatus.WAITING_APPROVAL.value,
        SessionStatus.RECOVERING.value,
    )

    @staticmethod
    def _timestamp(value: Any) -> datetime | None:
        text = str(value or "").strip()
        if not text:
            return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)

    def settle_orphan_sessions(self, *, idle_seconds: int = 1800, limit: int = 5000) -> dict[str, Any]:
        """Settle sessions that still claim activity but hold no live work.

        A session is reconciled only when every piece of evidence agrees that
        nothing is in flight:

        * its status claims activity (running / planning / verifying / queued /
          recovering / waiting_approval);
        * no tool call is effectively active (the assistant's own definition
          already ignores gates whose approval expired or was rejected);
        * no approval gate is pending and unexpired;
        * the assistant Run that owns it, when one exists, has already stopped;
        * the newest recorded activity is older than ``idle_seconds``.

        The settled status mirrors the evidence: the owning Run's resting status
        when the Run exists, otherwise the latest tool-call outcome, otherwise
        ``blocked`` for an undecided gate.  Nothing is deleted; every change is
        recorded as a ``session.reconciled`` event so the repair stays auditable.
        """

        now = datetime.now(timezone.utc)
        try:
            self.assistant.close_idle_planning(idle_seconds=idle_seconds)
        except Exception:
            logger.exception("close_idle_planning failed during settle_orphan_sessions")
        reconciled: list[dict[str, Any]] = []
        skipped: dict[str, int] = {}

        def skip(reason: str) -> None:
            skipped[reason] = skipped.get(reason, 0) + 1

        # Approval rows use "pending" for an undecided gate; only an unexpired one
        # still blocks its session from being settled.
        fresh_gates: set[str] = set()
        for approval in self.store.list_approvals(status="pending", limit=100_000):
            deadline = self._timestamp(approval.get("expires_at"))
            if deadline is None or deadline > now:
                fresh_gates.add(str(approval.get("session_id") or ""))

        for session in self.store.list_sessions(limit=limit):
            session_id = str(session.get("id") or "")
            status = str(session.get("status") or "")
            if not session_id or status not in self.ACTIVE_SESSION_STATUSES:
                continue
            calls = self.store.list_tool_calls(session_id, limit=2000)
            if self.assistant._effective_active_tool_calls(session_id, calls):
                skip("tool_call_active")
                continue
            if session_id in fresh_gates:
                skip("approval_pending")
                continue
            from .run_supervisor import job_is_live
            if job_is_live(session_id):  # t238 C7e A4: queued/running GPU job with a live lease heartbeat (provider; default never)
                skip("scheduler_job_live")
                continue
            run = self.store.get_assistant_run(session_id)
            run_status = str((run or {}).get("status") or "")
            if run and run_status in self.ACTIVE_RUN_STATUSES:
                skip("run_still_owns_lifecycle")
                continue
            # ``updated_at`` already covers creation (every create writes it),
            # so activity is measured from it plus the tool-call timeline.
            stamps = [self._timestamp(session.get("updated_at"))]
            for call in calls:
                stamps.append(self._timestamp(call.get("completed_at")))
                stamps.append(self._timestamp(call.get("started_at")))
                stamps.append(self._timestamp(call.get("created_at")))
            newest = max((stamp for stamp in stamps if stamp is not None), default=None)
            if newest is not None and (now - newest).total_seconds() < idle_seconds:
                skip("recent_activity")
                continue
            target = self._settled_session_status(run_status, calls)
            if target == status:
                skip("already_settled")
                continue
            self.store.update_session(session_id, status=target)
            self.store.append_event(
                session_id,
                "session.reconciled",
                {
                    "previous_status": status,
                    "status": target,
                    "reason": "no_live_work",
                    "run_status": run_status,
                    "tool_call_count": len(calls),
                    "last_activity_at": newest.isoformat() if newest else "",
                    "idle_seconds": idle_seconds,
                },
            )
            reconciled.append({"session_id": session_id, "from": status, "to": target})
        return {
            "checked_at": now.isoformat(),
            "reconciled_count": len(reconciled),
            "reconciled": reconciled,
            "skipped": dict(sorted(skipped.items())),
        }

    def _settled_session_status(self, run_status: str, calls: list[dict[str, Any]]) -> str:
        """Return the status that current evidence supports for a resting session."""

        if run_status:
            return run_status
        if calls:
            latest = max(
                calls,
                key=lambda item: (str(item.get("created_at") or ""), str(item.get("id") or "")),
            )
            latest_status = str(latest.get("status") or "")
            if latest_status == "completed":
                return SessionStatus.COMPLETED.value
            if latest_status == "failed":
                return SessionStatus.FAILED.value
            if latest_status == "waiting_approval":
                return SessionStatus.BLOCKED.value
            return SessionStatus.FAILED.value
        return SessionStatus.BLOCKED.value

    def _message_tool_specs(
        self,
        content: str,
        session: dict[str, Any],
        extra_names: set[str] | None = None,
    ) -> list[Any]:
        if self.super_agent.mode is SuperAgentMode.OFF:
            specs = [item for item in self.registry.specs_for_prompt(content) if item.available]
        else:
            essential = {
                "super_agent_status", "capability_discover", "ecosystem_refresh", "connector_health",
                "directory_list", "directory_stat", "directory_read", "directory_hash",
                "directory_mkdir", "directory_write_atomic", "directory_copy", "directory_sync", "directory_delete",
                "tool_synthesize", "tool_test", "tool_canary", "tool_promote", "tool_reject",
                "transfer_fetch", "job_execute", "job_status", "job_cancel",
                "file_list", "file_search", "file_read", "file_write", "file_patch",
                "shell_exec", "process_start", "process_list", "process_poll", "process_log", "process_stdin", "process_cancel",
                "attachment_list", "attachment_read", "artifact_publish", "artifact_list", "artifact_preview", "artifact_bundle",
                "runtime_health", "research_capabilities", "verified_context", "skill_list", "training_route", "memory_remember",
                "hpc_execution_budget_status",
                "managed_model_prepare", "artifact_import",
                "model_protocols", "managed_tensor_train",
                "report_generate", "report_status",
            }
            discovered = {
                item["descriptor"]["capability_id"]
                for item in self.super_agent.discover(
                    content,
                    healthy_only=True,
                    run_id=str(session.get("id") or "") or None,
                    workspace_root=session.get("workspace_root"),
                    metadata=session.get("metadata") if isinstance(session.get("metadata"), dict) else {},
                    limit=80,
                )
            }
            selected = essential | discovered | set(extra_names or ())
            specs = [item for item in self.registry.specs() if item.available and item.name in selected]
        metadata = session.get("metadata") if isinstance(session.get("metadata"), dict) else {}
        allowed = {
            str(value)
            for value in (metadata.get("run_allowed_tool_names") or [])
            if str(value)
        }
        if allowed:
            specs = [item for item in specs if item.name in allowed]
        from .personal_tool_boundary import offered, session_tenant
        tenant_id = session_tenant(session)
        return [item for item in specs if offered(tenant_id, item.name)]

    def _empty_failover_client(self, session_id: str, turn, make_client):
        """No silent provider switch. message() no longer calls this.

        The historical target is still ``empty_failover_transport`` (DeepSeek 4.1 Flash on the
        tri-vendor list). A different model is a new run the person starts from the picker.
        """
        del session_id, turn, make_client
        return None

    def message(self, session_id: str, content: str, *, max_steps: int = 12) -> dict[str, Any]:
        if self.get_session(session_id)["status"] == "cancelled":
            return {"status": "cancelled", "text": "Task cancelled; no new work was dispatched."}
        if self.user_pause_requested(session_id):
            return {"status": "paused", "text": "Task paused by the user; no new work was dispatched."}
        self.store.add_turn(session_id, "user", content)
        session = self.get_session(session_id)
        if (session.get("metadata") or {}).get("research_orchestrator") == "aibuildai2":
            from .aibuild_engine import AIBuildEngine
            try:
                return AIBuildEngine(self, session).execute()
            except Exception as exc:
                import re
                detail = str(exc)
                code = detail if re.fullmatch(r"[A-Za-z0-9_:-]{1,160}", detail) else safe_text(type(exc).__name__)
                self.store.append_event(session_id, "research_outcome", {"status": "blocked", "error_class": code, "objective_outcome": "not_verified"})
                self.store.update_session(session_id, status="blocked")
                return {"status": "blocked", "text": f"Research state retained; orchestration requires attention ({code}).", "error_class": code}
        from .run_supervision import shadow_plans_enabled
        # Run supervision v1: shadow task graphs only on request (666 graphs stayed `planned` and were never read).
        if self.super_agent.mode is not SuperAgentMode.OFF and shadow_plans_enabled():
            try:
                kernel = self.super_agent.shadow_plan(
                    run_id=session_id,
                    objective=str(session.get("objective") or content),
                    workspace_root=session.get("workspace_root"),
                    metadata=session.get("metadata") if isinstance(session.get("metadata"), dict) else {},
                )
                self.store.append_event(
                    session_id,
                    "super_agent.shadow_planned",
                    {
                        "schema": "evomind.super_agent_shadow.v1",
                        "mode": self.super_agent.mode.value,
                        "graph_id": kernel.graph.id,
                        "ready_node_ids": [item.id for item in kernel.graph.ready_nodes()],
                        "capability_count": len(self.super_agent.catalog.all(run_id=session_id)),
                    },
                )
            except Exception as exc:
                self.store.append_event(
                    session_id,
                    "super_agent.shadow_failed",
                    {"error_class": type(exc).__name__, "mode": self.super_agent.mode.value},
                )
        personal_binding = (session.get('metadata') or {}).get('model_profile')
        session_meta = session.get('metadata') or {}
        chosen_platform = str(session_meta.get('platform_model_id') or '')
        reasoning_effort = str(session_meta.get('reasoning_effort') or '')
        if not personal_binding:
            if chosen_platform:
                from .model_router import platform_transport_for
                from .models import ModelDecision
                selected = platform_transport_for(chosen_platform)
                if selected is None:
                    raise RuntimeError('platform_model_unavailable')
                decision = ModelDecision('execution', selected.name, selected.config.model, 'Explicit platform model from the resolved transport list; no fallback.', [], False)
            else:
                decision = self.router.route("execution", session["selected_model_policy"])
            self.store.append_event(session_id, "model.routed", decision.to_dict())
        else:
            from .models import ModelDecision
            decision = ModelDecision('execution', personal_binding['provider'], personal_binding['model'], 'Explicit personal profile revision; no fallback.', [], False)
        try:
            from research_os.agent.messaging import AgentMessageClient
            from research_os.agent.messaging import ToolResult as MessageToolResult
            from research_os.agent.messaging import ToolSpec as MessageToolSpec

            from .model_transport import governed_client, bind_run_client
            from .model_router import apply_reasoning_effort
            def guard_model_stream():
                session_state = self.get_session(session_id)
                if session_state['status'] == 'cancelled':
                    raise RuntimeError('user_cancel_requested')
                if (session_state.get('metadata') or {}).get('user_pause_requested'):
                    from .run_control import RunPaused
                    raise RunPaused()

            def guard_model_dispatch():
                if "siim_calibration" in (self.get_session(session_id).get("metadata") or {}):
                    from .siim_calibration_control import before_model_attempt as siim_model_gate
                    siim_model_gate(self, session_id)
                if "official_calibration" in (self.get_session(session_id).get("metadata") or {}):
                    from .ev_calibration_control import before_model_attempt
                    before_model_attempt(self, session_id)
                guard_model_stream()
            from .chat_stream_transport import PublicTextStream
            text_stream = PublicTextStream(lambda value: self.store.append_event(session_id, 'assistant.stream', value), guard_model_stream)
            if personal_binding:
                from .personal_model_client import client_for_run
                client = client_for_run(self, session, before_attempt=guard_model_dispatch,
                                         text_observer=text_stream, during_request=guard_model_stream,
                                         reasoning_effort=reasoning_effort)
                self.store.append_event(session_id, 'model.personal_profile_bound', personal_binding)
            else:
                from .model_router import apply_reasoning_effort, platform_transport_for, product_default_transports, require_served_identity
                product_default = None if chosen_platform else product_default_transports()
                if chosen_platform:
                    selected = platform_transport_for(chosen_platform)
                    if selected is None:
                        raise RuntimeError('platform_model_unavailable')
                    # A substitute model answering the user's pick is not success (t237 C4.1).
                    message_client = AgentMessageClient(transports=[require_served_identity(apply_reasoning_effort(selected, reasoning_effort))])
                elif product_default:
                    # The picker names the first transport. The rest are other models, not silent substitutes.
                    message_client = AgentMessageClient(transports=[require_served_identity(apply_reasoning_effort(product_default[0], reasoning_effort))])
                elif reasoning_effort:
                    from research_os.agent.messaging import _resolve_transports
                    resolved = [apply_reasoning_effort(item, reasoning_effort) for item in _resolve_transports()]
                    message_client = AgentMessageClient(transports=[require_served_identity(resolved[0])]) if resolved else AgentMessageClient()
                else:
                    from research_os.agent.messaging import _resolve_transports
                    resolved = _resolve_transports()
                    message_client = AgentMessageClient(transports=[require_served_identity(resolved[0])]) if resolved else AgentMessageClient()
                client = governed_client(message_client, lambda value: self.store.append_event(session_id, "model.transport_attempt", value),
                                         before_attempt=guard_model_dispatch, text_observer=text_stream, during_request=guard_model_stream)
                bind_run_client(self.store, session_id, client)
            # t238 C7e A1: failover across configured equivalent backends (implicit selection), or to the
            # user's own pre-selected fallback (explicit). No config and no fallback = same client, metrics only.
            from .llm_backends import wrap_run_client
            make_alternate_client = lambda transport: governed_client(
                AgentMessageClient(transports=[apply_reasoning_effort(transport, reasoning_effort)]),
                lambda value: self.store.append_event(session_id, "model.transport_attempt", value),
                before_attempt=guard_model_dispatch, text_observer=text_stream, during_request=guard_model_stream)
            client = wrap_run_client(self, session_id, client, explicit=bool(chosen_platform or personal_binding),
                                     reasoning_effort=reasoning_effort, make_client=make_alternate_client)
            if not client.is_available():
                raise RuntimeError("no configured model provider")
            from .message_journal import MessageJournal
            journal = MessageJournal(self, session_id)
            pending = journal.settle()
            if pending and pending["status"] != "settled":
                return pending
            fallback_messages = [
                {"role": item["role"], "content": item["content"]} for item in self.store.list_turns(session_id)
            ]
            messages = journal.history(fallback_messages)
            if messages is not fallback_messages:
                messages.append({"role": "user", "content": content})
            expanded_tool_names: set[str] = set()
            from .personal_tool_boundary import offered, session_tenant
            tenant_id = session_tenant(session)
            system = (
                "You are EvoMind, a durable task-completion agent. Plan, use tools, verify observations, preserve evidence, "
                "and continue until the objective is complete or an exact approval/input gate is reached. Work only inside "
                "the configured task workspace. Answer directly in Markdown by default; do not create a file just to answer a "
                "question. First decide whether a file is needed: only when the user explicitly asks for a file, or the result "
                "is a standalone, reusable, longer artifact (a document, a dataset, or code over 30 lines), write it to "
                "outputs/final/ and call artifact_publish. When you do create a file, still give a short Markdown summary "
                "(conclusion and key points) in the reply, and never copy the answer body verbatim into a file. A published file is shown "
                "to the user as a file card, so do not put download links, file URLs or \"Download\" lines in the reply, "
                "do not start a line with \"Download\" or paste artifact, sandbox: or ?download=1 URLs, and do not "
                "write English publish/verify phrases such as \"verified and published\"; write the reply in Chinese. A file write "
                "is not completion until the file is re-read or tested and published. Stop at "
                "approval gates for external or irreversible effects. To request approval, issue the exact intended tool call; "
                "the runtime policy will create the approval card. Never replace a required tool call with a prose-only approval request."
            )
            # Personal sessions are never offered these tools; do not instruct the model to call them.
            if offered(tenant_id, "capability_discover"):
                system += (
                    " Discover authorized capabilities before guessing a specialized tool. Address files as directory_id plus a "
                    "capability-relative path; never invent connector roots or absolute remote paths."
                )
            if offered(tenant_id, "training_route"):
                system += (
                    " Before fitting any model, call training_route with the attachment/path and the complete training request. "
                    "Obey its decision: local_cpu may use CPU only; hpc_gpu must call hpc_verify and pass all five current "
                    "identity samples before hpc_execute_solution. Never use a local GPU and never silently fall back to local "
                    "training when an HPC route is blocked. Collect, publish, and independently verify the resulting artifacts."
                )
            from .personal_tool_boundary import managed_training_clause, planning_resource_clause
            system += planning_resource_clause(tenant_id)
            system += managed_training_clause(tenant_id)
            model_execution: dict[str, Any] = {
                "provider": "",
                "model": "",
                "native_tool_loop": True,
                "native_tool_calls": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "turns": 0,
            }
            empty_terminal_turns = 0
            # C6b L14: adaptive summarized thinking on Anthropic transports when present.
            try:
                from research_os.agent.messaging import enable_anthropic_thinking
                targets = []
                single = getattr(client, "transport", None)
                if single is not None:
                    targets.append(single)
                inner = getattr(client, "client", None)
                if inner is not None and hasattr(inner, "_resolve_transports"):
                    targets.extend(inner._resolve_transports())
                elif hasattr(client, "_resolve_transports"):
                    targets.extend(client._resolve_transports())
                for item in targets:
                    enable_anthropic_thinking(item)
            except Exception:
                pass
            for step in range(max_steps):
                if self.user_pause_requested(session_id):
                    return {"status": "paused", "text": "Task paused at the next model-call boundary."}
                # C6b L11: inject pending steer at the next model/tool boundary.
                try:
                    steered = self.assistant.apply_pending_steer(session_id)
                except Exception:
                    steered = None
                if steered and str(steered.get("text") or "").strip():
                    steer_text = str(steered["text"]).strip()
                    messages.append({"role": "user", "content": steer_text})
                    self.store.add_turn(session_id, "user", steer_text)
                specs = [
                    MessageToolSpec(item.name, item.description, item.input_schema)
                    for item in self._message_tool_specs(content, session, expanded_tool_names)
                ]
                turn = client.send(messages, system=system, tools=specs,
                                   max_tokens=_message_max_output_tokens(session, client))
                model_execution.update(
                    {
                        "provider": turn.provider,
                        "model": turn.model,
                        "turns": step + 1,
                    }
                )
                model_execution["native_tool_calls"] += len(turn.tool_calls)
                model_execution["input_tokens"] += turn.input_tokens
                model_execution["output_tokens"] += turn.output_tokens
                self.store.append_event(
                    session_id,
                    "model.response",
                    {
                        "provider": turn.provider,
                        "model": turn.model,
                        "stop_reason": turn.stop_reason,
                        "input_tokens": turn.input_tokens,
                        "output_tokens": turn.output_tokens,
                        "tool_names": [requested.name for requested in turn.tool_calls],
                    },
                )
                try:
                    from research_os.agent.messaging import summarize_thinking
                    summary = summarize_thinking(turn)
                    if summary:
                        session_meta = dict((self.get_session(session_id).get("metadata") or {}))
                        session_meta["reasoning_summary"] = summary
                        self.store.update_session(session_id, metadata_json=session_meta)
                        self.store.append_event(session_id, "reasoning_summary", {"summary": summary})
                except Exception:
                    pass
                from .model_router import remember_served_model
                remember_served_model(self.store, session_id, turn.provider, turn.model)
                if not turn.text and not turn.tool_calls:
                    published_artifacts = self.store.list_deliverables(session_id)
                    # 2026-11-03: a run resumed after an approval executes the approved tool outside this loop, so the
                    # tool activity lives in the history, not in native_tool_calls (seen live: Opus 5.5 answered empty
                    # three times after a successful training and the finished run was marked blocked).
                    training_text = _training_completion_text(self.store, session_id) if published_artifacts else ""
                    tool_activity = bool(model_execution["native_tool_calls"]) or _history_has_tool_activity(messages) or bool(training_text)
                    if tool_activity and published_artifacts:
                        fallback_text = training_text or (
                            "The model returned no final prose after verified tool execution. "
                            "Use the published artifacts and run evidence as the authoritative result."
                        )
                        model_execution["completion_mode"] = "verified_artifact_fallback"
                        model_execution["verified_artifact_count"] = len(published_artifacts)
                        self.store.add_turn(session_id, "assistant", fallback_text)
                        self.store.append_event(
                            session_id,
                            "assistant.completed",
                            {
                                "text": fallback_text,
                                "degraded": True,
                                "reason": "empty_terminal_after_published_artifact",
                                "artifact_count": len(published_artifacts),
                            },
                        )
                        self.store.update_session(session_id, status=SessionStatus.COMPLETED.value)
                        return {
                            "status": "completed",
                            "text": fallback_text,
                            "model": decision.to_dict(),
                            "model_execution": model_execution,
                        }
                    empty_terminal_turns += 1
                    self.store.append_event(
                        session_id,
                        "model.empty_response",
                        {
                            "provider": turn.provider,
                            "model": turn.model,
                            "stop_reason": turn.stop_reason,
                            "attempt": empty_terminal_turns,
                        },
                    )
                    if empty_terminal_turns >= 3:
                        # The displayed model stays the displayed model. Another provider is a new run the person starts.
                        from .model_transport import ModelTransportError
                        raise ModelTransportError("model_empty_response", retryable=False)
                    continue
                empty_terminal_turns = 0
                messages.append({"role": "assistant", "content": turn.raw_content})
                shown = turn.text
                if turn.text and not turn.tool_calls:
                    from .personal_tool_boundary import annotate_unverified_zero_cost, zero_cost_was_confirmed
                    shown = annotate_unverified_zero_cost(
                        turn.text, confirmed=zero_cost_was_confirmed(self.store.list_tool_calls(session_id)),
                    )
                if shown:
                    self.store.add_turn(session_id, "assistant", shown)
                    self.store.append_event(session_id, "assistant.delta", {"text": shown})
                if not turn.tool_calls:
                    journal.save_history(messages)
                    self.store.update_session(session_id, status=SessionStatus.COMPLETED.value)
                    return {
                        "status": "completed",
                        "text": shown,
                        "model": decision.to_dict(),
                        "model_execution": model_execution,
                    }
                journal.begin(messages, turn.tool_calls, {spec.name for spec in specs})
                settled_batch = journal.settle()
                if settled_batch["status"] != "settled":
                    return {**settled_batch, "model": decision.to_dict(), "model_execution": model_execution}
                messages = settled_batch["messages"]
                # Discovery expands capabilities only after its persisted result.
                for requested in turn.tool_calls:
                    observed_call = self.store.get_idempotent_tool_call(session_id, requested.id)
                    result = (observed_call or {}).get("result", {})
                    if requested.name == "capability_discover" and bool(result.get("ok")):
                        content_payload = result.get("content") if isinstance(result.get("content"), dict) else {}
                        for match in content_payload.get("matches") or []:
                            descriptor = match.get("descriptor") if isinstance(match, dict) else None
                            capability_id = str(descriptor.get("capability_id") or "") if isinstance(descriptor, dict) else ""
                            if self.registry.get(capability_id) is not None:
                                expanded_tool_names.add(capability_id)
            self.store.update_session(session_id, status=SessionStatus.PAUSED.value)
            return {
                "status": "paused",
                "text": "tool step budget reached",
                "model": decision.to_dict(),
                "model_execution": model_execution,
            }
        except Exception as exc:
            if self.get_session(session_id)["status"] == "cancelled":
                return {"status": "cancelled", "text": "Task cancelled; existing receipts are preserved."}
            from .model_transport import ModelTransportError
            detail = exc.code if isinstance(exc, ModelTransportError) else type(exc).__name__
            if detail == "LLMError":  # t238 C7e A2: name the last HTTP status / timeout instead of the class
                from .llm_backends import public_code
                detail = public_code(exc)
            import re as _re
            if type(exc) is ValueError and _re.fullmatch(r"model_[a-z0-9_]{1,80}", str(exc)):
                # A personal-model worker failure is a plain ValueError whose text is already a public code
                # (model_http_401, model_transport_failed, ...). Naming it lets the UI tell a bad key from an
                # internal fault; any other ValueError text stays hidden behind the type name.
                detail = str(exc)
            text = f"Runtime session is durable. Model execution is unavailable: LLMError/{detail}. No tool was executed by the failed model request."
            self.store.add_turn(session_id, "assistant", text)
            contract_error = isinstance(exc, ValueError) and str(exc) in {
                'model_contract_drift', 'model_contract_invalid', 'legacy_model_contract_requires_review'}
            if isinstance(exc, ModelTransportError) or contract_error:
                detail = str(exc) if contract_error else exc.code
                self.store.append_event(session_id, 'assistant.blocked', {'error_code': detail, 'degraded': True})
                self.store.update_session(session_id, status=SessionStatus.BLOCKED.value)
                blocked = {'status': 'blocked', 'text': text, 'error_code': detail, 'model': decision.to_dict()}
                retry_after = getattr(exc, 'retry_after_seconds', None)
                if isinstance(retry_after, (int, float)) and retry_after > 0:
                    blocked['retry_after_seconds'] = float(retry_after)
                return blocked
            self.store.append_event(session_id, "assistant.completed", {"text": text, "degraded": True})
            self.store.update_session(session_id, status=SessionStatus.PAUSED.value)
            return {"status": "paused", "text": text, "model": decision.to_dict()}
