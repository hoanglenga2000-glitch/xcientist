CLASSES = ["EAP", "HPL", "MWS"]
