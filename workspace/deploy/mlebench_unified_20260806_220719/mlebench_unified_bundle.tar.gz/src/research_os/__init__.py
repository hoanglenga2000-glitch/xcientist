"""Minimal MLE-Bench deployment namespace."""
